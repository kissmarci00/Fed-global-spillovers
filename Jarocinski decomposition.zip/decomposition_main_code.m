
filename = 'decompdata.xlsx';
sheetname = 'data';
dataMatrix= readmatrix(filename, 'Sheet', sheetname);


[shocks,C,a]=signrestr_median(dataMatrix,0.5)

%first column of shocks is mp2_2day, i.e. True monetary policy shock
%second column of shocks is cbi2_2day, i.e. central bank information shock